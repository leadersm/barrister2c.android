package com.lsm.barrister2c.data.entity;

import java.io.Serializable;

/**
 * 学习中心频道
 */
public class Channel implements Serializable {
    public String id;
    public String title;
    public String desc;
}